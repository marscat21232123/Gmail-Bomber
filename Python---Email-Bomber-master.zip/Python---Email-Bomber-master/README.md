# Python Tutorial - || Create a EMAIL Bomb/Bomber || Code Walk-through || Hacking/Info-Sec ||

*#python* *#python 3* *#email* *#bomb* *#bomber* *#code* *#walk-through* *#hacking* *#info-sec* *#security* *#mass* *#spam* *#create*
*#how* *#to* *#code* *#script* *#kiddie*


![alt text](https://raw.githubusercontent.com/ncorbuk/Python---Email-Bomber/master/Email-Bomber%20v1.0%20Picture.jpg)

## Code Walk-through & Learning resources links
*If you are using a GMAIL or YAHOO account, you will need to change the settings to "Less Secure Apps" to allow python to send email using there servers, also may need to do that for OUTLOOK, or anyother EMAIL SERVER you use.... You may have to check.*

**YouTube tutorial: https://bit.ly/2Gxea9B**

**For python tutorials: https://bit.ly/2U58Lt9**

**Python_AND_Hacking subreddit: https://bit.ly/2Uf3gbw**

## Become a Patreon - support the channel
*Become a Patreon and support this channel, so that it can keep creating great content in the future* **LINK: https://www.patreon.com/w3w3w3**

## Built With

* **Python 3.6.5** - [https://www.python.org/](https://www.python.org/)
